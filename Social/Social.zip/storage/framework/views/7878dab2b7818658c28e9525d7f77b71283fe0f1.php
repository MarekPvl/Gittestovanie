<?php $__env->startSection('content'); ?>
	<?php if(Auth::check() and $user['id'] === Auth::user()->id ): ?>
	<div class="container">
		<div class="row">
			<div class="col-md3 mt-4">
				<div class="float-left text-center ">
					<div>
						<span>
							<img class="rounded-circle image-user" src="<?php echo e(URL::asset('storage/app/public/avatars/'.$user->avatar)); ?>" alt="<?php echo e($user->name); ?>" >
						</span>
					</div>
					<div>
						<h2 class=" header-width"><?php echo e($user->name); ?></h2>
						<h3 class="font-weight-light"><?php echo e($user->gender); ?></h3>
					</div>
				</div>
			</div>

			<div class="col-md-8 mt-4 ">
				<div class="float-right">
					<form class="margin-bottom" action="<?php echo e(url('newstatus')); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<textarea class="form-control rounded-0 mb-3 <?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" id="status" cols="60" rows="5" placeholder="Sem napíšte svoj status..." name="status" maxlength="100"></textarea>

						<?php if($errors->has('status')): ?>
							<span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('Country')); ?></strong>
                                    </span>
						<?php endif; ?>

						<input type="submit" class="btn btn-primary float-right" name="submit" value="Pridať status" required>
						
						</input>
					</form>

					<?php if( $statuses->isEmpty() ): ?>

						<div class="alert alert-info margin-top">
							Používateľ <strong><?php echo e($user->name); ?></strong> nemá žiadne statusy :(.
						</div>

					<?php else: ?>
						
						<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="alert alert-info ">
								<div class="row">
								<span>
									<img class="img-circle status-img" src="<?php echo e(URL::asset('storage/app/public/avatars/'.$status->avatar)); ?>" alt="">
								</span>
									<div class="flexbox">
										<p class="name"><?php echo e($status->name); ?></p>
										<p class="time"><?php echo e(date('H:i', strtotime($status->created_at))); ?></p>
									</div>
								</div>
								<div>
									<p class="status"><?php echo e($status->status); ?></p>
								</div>
							</div>
							
								<div class="row">
									<div class="like-button">
										<?php echo Form::open(['method' => 'POST', 'url' => 'like' ]); ?>

										<input name="statusid" type="hidden" value="<?php echo e($status->id); ?>">
										<?php if(count($status->like) > 0): ?>
											<button class="like <?php echo e((count($status->like()->where('user_id', '=', Auth::user()->id)->where('type', 'like')->get()))  ? 'like-users' : ''); ?>"
											        type="submit"><i class="fa fa-thumbs-down"></i>Páči sa mi to
												(<?php echo e(count($status->like)); ?>)
											</button>
										<?php else: ?>
											<button class="like" type="submit">
												<i class="fa fa-thumbs-down"></i>Páči sa mi to
											</button>
										<?php endif; ?>
										<?php echo Form::close(); ?>


									</div>

									<div class="dislike-button">
										<?php echo Form::open(['method' => 'POST', 'url' => 'dislike' ]); ?>

										<input name="statusid" type="hidden" value="<?php echo e($status->id); ?>">
										<?php if(count($status->dislike) > 0): ?>
											<button class="like <?php echo e((count($status->dislike()->where('user_id', '=', Auth::user()->id)->where('type', 'dislike')->get()))  ? 'like-users' : ''); ?>"
											        type="submit"><i class="fa fa-thumbs-down"></i>Nepáči sa mi to
												(<?php echo e(count($status->dislike)); ?>)
											</button>
										<?php else: ?>
											<button class="like" type="submit">
												<i class="fa fa-thumbs-down"></i>Nepáči sa mi to
											</button>
										<?php endif; ?>
										<?php echo Form::close(); ?>

									</div>
								</div>
							
							<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($status->id == $comment->statusid ): ?>
									<div class="row comment-conntent">
										<span class="comment-img">
												<img class="img-circle comment-img mb-2" src="<?php echo e(URL::asset('storage/app/public/avatars/'.$comment->avatar)); ?>" alt="">
											</span>

										<div class="comment-post">


											<p class="comment-box">

												<span class="user-name"><?php echo e($comment->name); ?></span>
												<span class="comment-text"><?php echo e($comment->comment); ?></span>
											</p>

										</div>

									</div>

									<div class="row">
										<div class="like-button-comment">
											<?php echo Form::open(['method' => 'POST', 'url' => 'like' ]); ?>

											<input name="commentid" type="hidden" value="<?php echo e($comment->id); ?>">
											<?php if(count($comment->commentlike) > 0): ?>
												<button class="like-comment <?php echo e((count($comment->commentlike()->where('user_id', '=', Auth::user()->id)->where                                                                                       ('type','like')->get()))  ? 'like-comment-users' : ''); ?>"
												        type="submit">
													<i class="fa fa-thumbs-up"></i>Páči sa mi to
													(<?php echo e(count($comment->commentlike)); ?>)
												</button>
											<?php else: ?>
												<button class="like-comment" type="submit"><i
															class="fa fa-thumbs-up"></i>Páči sa mi to
												</button>
											<?php endif; ?>
											<?php echo Form::close(); ?>

										</div>
										<div class="dislike-button-comment">
											<?php echo Form::open(['method' => 'POST', 'url' => 'dislike' ]); ?>

											<input name="commentid" type="hidden" value="<?php echo e($comment->id); ?>">
											<?php if(count($comment->commentdislike) > 0): ?>
												<button class="like-comment <?php echo e((count($comment->commentdislike()->where('user_id', '=', Auth::user()->id)->where                                                                                       ('type','dislike')->get()))  ? 'like-comment-users' : ''); ?>"
												        type="submit">
													<i class="fa fa-thumbs-up"></i>Nepáči sa mi to
													(<?php echo e(count($comment->commentdislike)); ?>)
												</button>
											<?php else: ?>
												<button class="like-comment" type="submit"><i
															class="fa fa-thumbs-up"></i>Nepáči sa mi to

												</button>
											<?php endif; ?>
											<?php echo Form::close(); ?>

										</div>
									</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


							<div class="row comment">
								<div>
									<img class="img-circle status-img" src="<?php echo e(URL::asset('storage/app/public/avatars/'.Auth::user()->avatar)); ?>" alt="">
								</div>



								
								<div>
									<form action="<?php echo e(url('newcomment')); ?>" method="POST">
										<?php echo e(csrf_field()); ?>

										<input id="comment" type="text" class="form-control comment-input" name="comment<?php echo e($status->id); ?>" placeholder="Napíšte komentár..." autocomplete="off" data-single-click>
										<input name="statusid" type="hidden" value="<?php echo e($status->id); ?>">
										<input type="submit" style="visibility: hidden;" />
									</form>
								</div>

							</div>


						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php echo e($statuses->links()); ?>


					<?php endif; ?>

				</div>

			</div>
		</div>
	</div>
	<?php else: ?>
		<div class="container">
			<div class="row">
				<div class="col-md3 mt-4">
					<div class="float-left text-center ">
						<div>
						<span>
							<img class="rounded-circle image-user" src="<?php echo e(URL::asset('storage/app/public/avatars/'.$user->avatar)); ?>" alt="<?php echo e($user->name); ?>" >
						</span>
						</div>
						<div>
							<h2 class=" header-width"><?php echo e($user->name); ?></h2>
							<h3 class="font-weight-light"><?php echo e($user->gender); ?></h3>
							<?php if(auth()->guard()->guest()): ?>

							<?php else: ?>
								<?php if( count($existsfriendsa) > '0' or count($existsfriendsb) > '0' ): ?>
									<?php echo Form::open(['method' => 'POST', 'url' => 'Deletefriend' ]); ?>

									<input name="userid" type="hidden" value="<?php echo e($user->id); ?>">
										<button class="add-friend" type="submit">
											<i class="fa fa-ban"></i>
											Odstrániť priateľa
										</button>
									<?php echo Form::close(); ?>

								<?php elseif( count($existsfriendsrequesta) > '0' or count($existsfriendsrequestb) > '0'  ): ?>
									<?php echo Form::open(['method' => 'POST', 'url' => 'Deleterequest' ]); ?>

									<input name="userid" type="hidden" value="<?php echo e($user->id); ?>">
										<button class="add-friend" type="submit">
											<i class="fa fa-ban"></i>
											Zrušiť žiadosť o priateľstvo
										</button>
									<?php echo Form::close(); ?>

								<?php else: ?>
									<?php echo Form::open(['method' => 'POST', 'url' => 'Addfriend' ]); ?>

									<input name="userid" type="hidden" value="<?php echo e($user->id); ?>">
										<button class="add-friend" type="submit">
											<i class="fa fa-user-plus"></i>
											Pridať priateľa
										</button>
									<?php echo Form::close(); ?>

								<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
				</div>

				<div class="col-md-8 mt-4 ">
					<div class="float-right">

						<?php if( $statuses->isEmpty() ): ?>

							<div class="alert alert-info margin-top">
								Používateľ <strong><?php echo e($user->name); ?></strong> nemá žiadne statusy :(.
							</div>

						<?php else: ?>
							<?php if(auth()->guard()->guest()): ?>
								<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="alert alert-info ">
										<div class="row">
									<span>
										<img class="img-circle status-img" src="<?php echo e(URL::asset('storage/app/public/avatars/'.$status->avatar)); ?>" alt="">
									</span>
											<div class="flexbox">
												<p class="name"><?php echo e($status->name); ?></p>
												<p class="time"><?php echo e(date('H:i', strtotime($status->created_at))); ?></p>
											</div>
										</div>
										<div>
											<p class="status"><?php echo e($status->status); ?></p>
										</div>
									</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<?php echo e($statuses->links()); ?>


							<?php else: ?>

								<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="alert alert-info ">
											<div class="row">
								<span>
									<img class="img-circle status-img" src="<?php echo e(URL::asset('storage/app/public/avatars/'.$status->avatar)); ?>" alt="">
								</span>
												<div class="flexbox">
													<p class="name"><?php echo e($status->name); ?></p>
													<p class="time"><?php echo e(date('H:i', strtotime($status->created_at))); ?></p>
												</div>
											</div>
											<div>
												<p class="status"><?php echo e($status->status); ?></p>
											</div>
										</div>

										

									<div class="row">
										<div class="like-button">
											<?php echo Form::open(['method' => 'POST', 'url' => 'like' ]); ?>

											<input name="statusid" type="hidden" value="<?php echo e($status->id); ?>">
											<?php if(count($status->like) > 0): ?>
												<button class="like <?php echo e((count($status->like()->where('user_id', '=', Auth::user()->id)->where('type', 'like')->get()))  ? 'like-users' : ''); ?>"
												        type="submit"><i class="fa fa-thumbs-down"></i>Páči sa mi to
													(<?php echo e(count($status->like)); ?>)
												</button>
											<?php else: ?>
												<button class="like" type="submit">
													<i class="fa fa-thumbs-down"></i>Páči sa mi to
												</button>
											<?php endif; ?>
											<?php echo Form::close(); ?>


										</div>

										<div class="dislike-button">
											<?php echo Form::open(['method' => 'POST', 'url' => 'dislike' ]); ?>

											<input name="statusid" type="hidden" value="<?php echo e($status->id); ?>">
											<?php if(count($status->dislike) > 0): ?>
												<button class="like <?php echo e((count($status->dislike()->where('user_id', '=', Auth::user()->id)->where('type', 'dislike')->get()))  ? 'like-users' : ''); ?>"
												        type="submit"><i class="fa fa-thumbs-down"></i>Nepáči sa mi to
													(<?php echo e(count($status->dislike)); ?>)
												</button>
											<?php else: ?>
												<button class="like" type="submit">
													<i class="fa fa-thumbs-down"></i>Nepáči sa mi to
												</button>
											<?php endif; ?>
											<?php echo Form::close(); ?>

										</div>
									</div>

										
									<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($status->id == $comment->status_id ): ?>
											<div class="row comment-conntent">
										<span class="comment-img">
												<img class="img-circle comment-img mb-2" src="<?php echo e(URL::asset('storage/app/public/avatars/'.$comment->avatar)); ?>" alt="">
											</span>

												<div class="comment-post">


													<p class="comment-box">

														<span class="user-name"><?php echo e($comment->name); ?></span>
														<span class="comment-text"><?php echo e($comment->comment); ?></span>
													</p>

												</div>

											</div>

										

											<div class="row">
												<div class="like-button-comment">
													<?php echo Form::open(['method' => 'POST', 'url' => 'like' ]); ?>

													<input name="commentid" type="hidden" value="<?php echo e($comment->id); ?>">
													<?php if(count($comment->commentlike) > 0): ?>
														<button class="like-comment <?php echo e((count($comment->commentlike()->where('user_id', '=', Auth::user()->id)->where                                                                                       ('type','like')->get()))  ? 'like-comment-users' : ''); ?>"
														        type="submit">
															<i class="fa fa-thumbs-up"></i>Páči sa mi to
															(<?php echo e(count($comment->commentlike)); ?>)
														</button>
													<?php else: ?>
														<button class="like-comment" type="submit"><i
																	class="fa fa-thumbs-up"></i>Páči sa mi to
														</button>
													<?php endif; ?>
													<?php echo Form::close(); ?>

												</div>
												<div class="dislike-button-comment">
													<?php echo Form::open(['method' => 'POST', 'url' => 'dislike' ]); ?>

													<input name="commentid" type="hidden" value="<?php echo e($comment->id); ?>">
													<?php if(count($comment->commentdislike) > 0): ?>
														<button class="like-comment <?php echo e((count($comment->commentdislike()->where('user_id', '=', Auth::user()->id)->where                                                                                       ('type','dislike')->get()))  ? 'like-comment-users' : ''); ?>"
														        type="submit">
															<i class="fa fa-thumbs-up"></i>Nepáči sa mi to
															(<?php echo e(count($comment->commentdislike)); ?>)
														</button>
													<?php else: ?>
														<button class="like-comment" type="submit"><i
																	class="fa fa-thumbs-up"></i>Nepáči sa mi to

														</button>
													<?php endif; ?>
													<?php echo Form::close(); ?>

												</div>
											</div>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


									<div class="row comment">
										<div>
											<img class="img-circle status-img" src="<?php echo e(URL::asset('storage/app/public/avatars/'.Auth::user()->avatar)); ?>" alt="">
										</div>




										<div>
											<form action="<?php echo e(url('newcomment')); ?>" method="POST">
												<?php echo e(csrf_field()); ?>

												<input id="comment" type="text" class="form-control comment-input" name="comment<?php echo e($status->id); ?>" placeholder="Napíšte komentár..." autocomplete="off" data-single-click>
												<input name="statusid" type="hidden" value="<?php echo e($status->id); ?>">
												<input type="submit" style="visibility: hidden;" />
											</form>
										</div>

									</div>


								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<?php echo e($statuses->links()); ?>

							<?php endif; ?>
						<?php endif; ?>

					</div>

				</div>
			</div>
		</div>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>