<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header"><?php echo e(__('Zoznam používateľov')); ?></div>

					<div class="card-body">
						<div class="container">

							<table class="table table-striped table-bordered">
								<tr>

									<th><strong>Foto</strong></th>
									<th><strong>Meno používateľa</strong></th>
									<th><strong>Dátum registrácie</strong></th>
								</tr>

								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><span class="avatar">
		                                <a href="<?php echo e(route('user.view',['name' => $user->name])); ?>"><img
					                                class="profile-img"
					                                src="<?php echo e(URL::asset('storage/app/public/avatars/'.$user->avatar)); ?>"
					                                alt="<?php echo e($user->name); ?>"></a>
	                                </span></td>

										<td><a class="text-dark"
										       href="<?php echo e(route('user.view',['name' => $user->name])); ?>"><?php echo e($user->name); ?></a>
										</td>
										<td><?php echo e(date('d.m.Y', strtotime($user->created_at))); ?></td>
									</tr>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>

							<?php echo e($users->links()); ?>



							

						</div>

					</div>

				</div>
			</div>
		</div>
	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>