<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-8">
				<div class="card">
					<div class="card-header"><?php echo e(__('Žiadosti o priateľstvo')); ?></div>

					<div class="card-body">
						<div class="container">

							<table class="table table-striped table-bordered">
								<tr>

									<th><strong>Foto</strong></th>
									<th><strong>Meno používateľa</strong></th>
									<th><strong>Dátum odoslania</strong></th>
									<th><strong>Prijať/Odmietnuť</strong></th>

								</tr>

								<?php $__currentLoopData = $Friendsrequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Friendsrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><span class="avatar">
		                                <a href="<?php echo e(route('user.view',['name' => $Friendsrequest->requestername])); ?>"><img
					                                class="profile-img"
					                                src="<?php echo e(URL::asset('storage/app/public/avatars/'.$Friendsrequest->requesteravatar)); ?>"
					                                alt="<?php echo e($Friendsrequest->requestername); ?>"></a>
	                                </span></td>

										<td><a class="text-dark"
										       href="<?php echo e(route('user.view',['name' => $Friendsrequest->requestername])); ?>"><?php echo e($Friendsrequest->requestername); ?></a>
										</td>
										<td><?php echo e(date('d.m.Y', strtotime($Friendsrequest->created_at))); ?></td>

											<td class="row friends-button ">
												<?php echo Form::open(['method' => 'POST', 'url' => 'Acceptfriend' ]); ?>

												<input name="userid" type="hidden" value="<?php echo e($Friendsrequest->id); ?>">
												<button type="submit" class="btn btn-success btn-sm">Prijať</button>
												<?php echo Form::close(); ?>

												&nbsp
												<?php echo Form::open(['method' => 'POST', 'url' => 'Rejectfriend' ]); ?>

												<input name="userid" type="hidden" value="<?php echo e($Friendsrequest->id); ?>">
												<button type="submit" class="btn btn-danger btn-sm">Zamietnuť</button>
												<?php echo Form::close(); ?>


											</td>
										</div>
									</tr>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>

							<?php echo e($Friendsrequests->links()); ?>


						</div>

					</div>

				</div>
			</div>
		</div>
	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>