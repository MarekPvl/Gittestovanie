<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card-edit">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form class="inputs" method="POST" action="<?php echo e(url('update')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($userdata->name); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($userdata->email); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

	                    <!-- *
	                         **
	                         ***Pridane vlastne itemy
	                         -->

	                    <div class="form-group row">
		                    <label for="birth" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Birth')); ?></label>

		                    <div class="col-md-6">
			                    <input id="birth" type="date" class="form-control<?php echo e($errors->has('birth') ? ' is-invalid' : ''); ?>" name="birth" value="<?php echo e($userdata->birth); ?>" required autofocus>

			                    <?php if($errors->has('birth')): ?>
				                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('birth')); ?></strong>
                                    </span>
			                    <?php endif; ?>
		                    </div>
	                    </div>

	                     <div class="form-group row <?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
		                    <label for="gender" class="col-md-4 col-form-label text-md-right">Gender</label>
							<?php if( $userdata->gender == "male"): ?>
			                    <div class="col-md-6">
				                    <select name="gender" class="col-md-4 form-control" selected="<?php echo e($userdata->gender); ?>">
					                    <option value="male" selected>Male</option>
					                    <option value="female">Female</option>
				                    </select>
				                    <?php if($errors->has('gender')): ?>
					                    <span class="help-block">
	                                        <strong><?php echo e($errors->first('gender')); ?></strong>
	                                    </span>
				                    <?php endif; ?>
			                    </div>
	                    </div>
						<?php else: ?>
		                    <div class="col-md-6">
			                    <select name="gender" class="col-md-4 form-control" selected="<?php echo e($userdata->gender); ?>">
				                    <option value="male">Male</option>
				                    <option value="female" selected>Female</option>
			                    </select>
			                    <?php if($errors->has('gender')): ?>
				                    <span class="help-block">
                                        <strong><?php echo e($errors->first('gender')); ?></strong>
                                    </span>
			                    <?php endif; ?>
		                    </div>
                </div>
						<?php endif; ?>
	                    <div class="form-group row">
		                    <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('City')); ?></label>

		                    <div class="col-md-6">
			                    <input id="city" type="text" class="form-control<?php echo e($errors->has('city') ? ' is-invalid' : ''); ?>"      name="city" value="<?php echo e($userdata->city); ?>" required autofocus>

			                    <?php if($errors->has('city')): ?>
				                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
			                    <?php endif; ?>
		                    </div>
	                    </div>

	                    <div class="form-group row">
		                    <label for="country" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country')); ?></label>

		                    <div class="col-md-6">
			                    <input id="Country" type="text" class="form-control<?php echo e($errors->has('Country') ? ' is-invalid' : ''); ?>" name="country" value="<?php echo e($userdata->country); ?>" required autofocus>

			                    <?php if($errors->has('Country')): ?>
				                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('Country')); ?></strong>
                                    </span>
			                    <?php endif; ?>
		                    </div>
	                    </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Uložiť zmeny')); ?>

                                </button>
                            </div>
                        </div>
                    </form>

	            <span class="edit-picture"><img class="edit-img"
	                                            src="<?php echo e(URL::asset('storage/app/public/avatars/'.Auth::user()->avatar)); ?>"
	                                            alt="<?php echo e(Auth::user()->name); ?>"></span>

		            <div class="form-group row file">
			            <label for="name" class="col-form-label text-md-right file-label"><?php echo e(__('Profilový obrázok')); ?></label>

			            <form method="POST" action="<?php echo e(url('image')); ?>" enctype="multipart/form-data">
			            <div class="col-md-6">
				            <?php echo e(csrf_field()); ?>

					            <input id="avatar" type="file" class="file-input form-control<?php echo e($errors->has('avatar') ? ' is-invalid' : ''); ?>" name="avatar" value="<?php echo e($userdata->avatar); ?>" required autofocus>
					            <input class="file-button" type="submit" value="Vložiť fotku" name="submit">

					            <?php if($errors->has('avatar')): ?>
						            <span class="invalid-feedback">
		                                        <strong><?php echo e($errors->first('avatar')); ?></strong>
		                                    </span>
				            <?php endif; ?>
			            </div>
				        </form>
		            </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>